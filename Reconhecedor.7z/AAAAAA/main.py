import os
import cv2
import mediapipe as mp
import pyttsx3
import speech_recognition as sr
import webbrowser
from datetime import datetime



webcam = cv2.VideoCapture(0)
solucao_reconhecimento_rosto = mp.solutions.face_detection
reconhecedor_rostos = solucao_reconhecimento_rosto.FaceDetection()
quadrado = mp.solutions.drawing_utils
recon = sr.Recognizer()
resposta = ""
hora = (str(datetime.today().hour) + ":" + str(datetime.today().minute))



print("mostre o rosto por favor")
while webcam.isOpened():
    verificador, frame = webcam.read()
    if not verificador:
        break

    lista_rostos = reconhecedor_rostos.process(frame)

    if lista_rostos.detections:
        for rosto in lista_rostos.detections:
            quadrado.draw_detection(frame, rosto)
        cv2.imshow("Rostos na webcam", frame)
        if cv2.waitKey(1000) == 27:
            break

        robo = pyttsx3.init()
        robo.say("Olá seja bem vindo, o que deseja?")
        robo.setProperty("voice", b'brasil')
        robo.setProperty('rate', 140)
        robo.setProperty('volume', 1)
        robo.runAndWait()


        with sr.Microphone(1) as source:

            while True:

                audio = recon.listen(source)
                resposta = recon.recognize_google(audio, language='pt')
                print("Texto reconhecido: ", resposta)
                if resposta == "YouTube":
                    robo.say("Abrindo youtube")
                    robo.runAndWait()
                    webbrowser.open('https://www.youtube.com/', autoraise=True)


                if resposta == "notícias":
                    robo.say("Abrindo Cnn")
                    robo.runAndWait()
                    webbrowser.open('https://www.cnnbrasil.com.br/', autoraise=True)


                if resposta == "ativar protocolo sexta-feira":
                    robo.say("Ativando protocolo")
                    robo.runAndWait()
                    os.startfile('C:\Riot Games\Riot Client/RiotClientServices.exe')
                    webbrowser.open('https://music.youtube.com/watch?v=n2qTCfDOysM&list=RDAMVMPwnHHAIi0XQ', autoraise=True)


                if resposta == "Que horas são":
                    robo.say(hora)
                    print(hora)
                    robo.runAndWait()


                if resposta == "assuntos do momento":
                    robo.say("Mostrando as trendings")
                    robo.runAndWait()
                    webbrowser.open('https://twitter.com/explore/tabs/trending', autoraise=True)

                elif resposta == "parar":
                    robo.say("OK! Até mais tarde senhor!")
                    robo.runAndWait()
                    break


        webcam.release()
        cv2.destroyAllWindows()









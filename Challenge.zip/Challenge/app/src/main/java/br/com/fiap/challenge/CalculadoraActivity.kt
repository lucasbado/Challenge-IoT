package br.com.fiap.challenge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calculadora.*

class CalculadoraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        var btnResultado = findViewById<Button>(R.id.btnResultado)
        btnResultado.setOnClickListener{
            var valor1 = findViewById<EditText>(R.id.txtValue1)
            var resultValor1 = valor1.text.toString().toDouble()

            var valor2 = findViewById<EditText>(R.id.txtValue2)
            var resultValor2 = valor2.text.toString().toDouble()

            var soma : Double = resultValor1 + resultValor2

            var divisao : Double = resultValor1 / resultValor2

            var subtracao : Double = resultValor1 - resultValor2

            var multiplicacao : Double = resultValor1 * resultValor2


            if (rdSoma.isChecked() ){
               soma

               Toast.makeText( this, "${soma}", Toast.LENGTH_LONG).show()
            }
            if (rdSub.isChecked() ){
                subtracao

                Toast.makeText( this, "${subtracao}", Toast.LENGTH_LONG).show()
            }
            if (rdMulti.isChecked() ){
                multiplicacao
                Toast.makeText( this, "${multiplicacao}", Toast.LENGTH_LONG).show()
            }
            if (rdDivi.isChecked() ){
                divisao

                Toast.makeText( this, "${divisao}", Toast.LENGTH_LONG).show()
            }
        }

    }
}
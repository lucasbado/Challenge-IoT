package br.com.fiap.challenge

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_resultado.*


class ContaActivity : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_conta)


            var btnConta = findViewById<Button>(R.id.btnConta)
            btnConta.setOnClickListener{
                var ass = findViewById<EditText>(R.id.assinatura)
                var precoAss = ass.text.toString().toDouble()

                var cLocal = findViewById<EditText>(R.id.cLocal)
                var precoCLocal = cLocal.text.toString().toDouble()

                var cCelular = findViewById<EditText>(R.id.cCelular)
                var precoCCelular = cCelular.text.toString().toDouble()


                var resultado : Double = precoAss + precoCLocal + precoCCelular

                var msg = "Assinatura        :R$ $precoAss\n" +
                        "Chama Local       :R$ $precoCLocal\n" +
                        "Chamada Celular   :R$ $precoCCelular\n" +
                        "\n" +
                        "Valor Total       :R$ $resultado"



                var intentResultado = Intent(this, ResultadoActivity::class.java)
                intentResultado.putExtra("msg", msg)
                startActivity(intentResultado)

            }
        }
    }

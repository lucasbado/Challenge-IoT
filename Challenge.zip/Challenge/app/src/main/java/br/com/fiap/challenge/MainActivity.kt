package br.com.fiap.challenge

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import br.com.fiap.challenge.R
import kotlinx.android.synthetic.main.activity_main.*




class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnIntegrantes.setOnClickListener{
            mostrarIntegrantes()
        }
        btnTelefone.setOnClickListener{

            var intentConta = Intent(this, ContaActivity::class.java)

            startActivity(intentConta)

        }
        btnCalculo.setOnClickListener{
            var intentCalculadora = Intent( this, CalculadoraActivity::class.java)

            startActivity(intentCalculadora)
        }

    }



    fun mostrarIntegrantes() {
        var builder = AlertDialog.Builder(this)
        builder
            .setTitle("Desenvolvido por: ")
            .setMessage("Lucas Alves \n" +
                    "Israel Vieira")
            .setPositiveButton("Ok", null)
        builder.create().show()
    }
}


